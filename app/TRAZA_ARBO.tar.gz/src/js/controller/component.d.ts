declare module 'vee-validate*';
declare var google;